def DevelopmentConfig():
    config = {
        'oauthServerIp' : 'http://192.168.2.208:5556',
        'oauthExternalIp' :'http://192.168.2.208:5556',
        'clientId' : '10',
        'viewer_clientId' : '11',
        'homePage' : 'http://192.168.2.208:8081/static/index.html',
        'loginPage' : 'http://192.168.2.208:8081/static/site/login.html',
        'viewerPage': 'http://192.168.2.18:25158/vstatic/sangrahi_viewer/index.html',
    }
    return config

def ProductionConfig():
    config = {
        'oauthServerIp' : 'http://192.168.2.17:5556',
        'oauthExternalIp' :'https://vedas.sac.gov.in/access',
        'clientId' : '10',
        'viewer_clientId' : '11',
        'homePage' : 'https://vedas.sac.gov.in/sangrahi_project_management/table',
        'viewerPage': 'https://vedas.sac.gov.in/vstatic/sangrahi_viewer/index.html',
        'loginPage' : 'https://vedas.sac.gov.in/sangrahi_project_management/login.html'
    }
    return config