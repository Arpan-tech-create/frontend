import flask
from random import randint
from flask import make_response, redirect, Response, request, send_from_directory, render_template
import requests
import json
import pandas as pd
from decode import TokenVerify
from config import ProductionConfig


app = flask.Flask(__name__, static_url_path='/sangrahi_project_management/static')

from config import ProductionConfig
config  = ProductionConfig()
print("config",config)


@app.route('/', methods=['GET'])
def index():
    return render_template('login.html')

@app.route('/table',methods=['GET'])
def log():
    return render_template('index.html')

#def fetch_project_list():
    url = "https://vedas.sac.gov.in/udc/schema/list?serviceVersions=2"

    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return []

@app.route('/data', methods=['GET'])
def get_user_data():
    project_id = request.args.get('projectId')
    print("project id",project_id)
    project_name=request.args.get('projectName')
    
    # Find the project name based on project ID
  #  project = next((project for project in project_list if project['id'] == project_id), None)
   # project_name = project['name'] if project else "Unknown Project"
    
    return render_template('data.html',project_id=project_id,project_name=project_name)





@app.route('/static/<path:path>')
def send_report(path):
    return send_from_directory('static', path)

def fetchAT():
    at = request.cookies.get('dAT')
    return at

def verifyToken(token):
    verifier = TokenVerify(key_file_path='pub.pem')
    status = verifier.decode(token, verify=True)
    return status

def authenticate(func):
    def inner(*args, **kwargs):
        print('inside decorator')
        at = fetchAT()
        status = verifyToken(at)
        print('status', status)
        if status is None:
            res = make_response(redirect(config['loginPage'], 302))
            return res
        print("status",status)
        print('decorator end')
        return func(*args, **kwargs)
    inner.__name__ = func.__name__
    return inner


@app.route("/login")
def login():
    print("H1")
    curr_val = request.cookies.get('state')
    state = str(randint(1, 100))
    dAT = fetchAT()
    status = verifyToken(dAT)
    if status is None:
        res = make_response(config['oauthExternalIp'] + '/login.html?state='+ state + '&clientId=' + config['clientId'])
        res.set_cookie('state', state, max_age=None, path='/', httponly=True)
    else:
        res = make_response(config['homePage'])
    return res

@app.route("/callback")
def callback():
    args = request.args
    access_code = args.get('accessCode')
    client_id = args.get('clientId')
    redirect_uri = args.get('resource_uri')
    print(access_code, client_id)
    print(config['clientId'])
    if len(access_code) <= 0 or access_code.lower() == 'DENY'.lower() :
        print('Error return')
        return make_response(redirect(config['loginPage']))
    out = requests.post(config['oauthServerIp'] +'/auth/token',
                  data= json.dumps({
                    "accessCode" : access_code
                  }),
                  headers = {
                    'x-client-id' : client_id,
                     'Content-Type' : 'application/json',
                      'Accept' :'application/json'
                  },
    )
    out = out.content.decode('utf-8')
    print("MY_TOKEN_Details",out)
    out = json.loads(out)
    data = out['data']
    access_token = 'Bearer ' + data['token']
    refresh_token = data['refreshToken']
    user = data['user']

    try:
        username = user['name']
    except:
        username = user['email'].split('@')[0]
    print("home page value",config['homePage'],redirect_uri)

    res = make_response(redirect(config['homePage'], 302))
    res.set_cookie('dAT', access_token, max_age=None, path='/',  secure=True, samesite='Strict')
    res.set_cookie('dRT', refresh_token, max_age=None, path='/',  secure=True, samesite='Strict')
    res.set_cookie('user', username, max_age=None, path='/', secure=True, samesite='Strict')
    return res

@app.route("/callback_viewer")
def callback_viewer():
    args = request.args
    access_code = args.get('accessCode')
    client_id = args.get('viewer_clientId')
    redirect_uri = args.get('resource_uri')
    print(access_code, client_id)
    print(config['viewer_clientId'])
    if len(access_code) <= 0 or access_code.lower() == 'DENY'.lower() :
        print('Error return')
        return make_response(redirect(config['loginPage']))
    out = requests.post(config['oauthServerIp'] +'/auth/token',
                  data= json.dumps({
                    "accessCode" : access_code
                  }),
                  headers = {
                    'x-client-id' : client_id,
                     'Content-Type' : 'application/json',
                      'Accept' :'application/json'
                  },
    )
    out = out.content.decode('utf-8')
    print("MY_TOKEN_Details",out)
    out = json.loads(out)
    data = out['data']
    access_token = 'Bearer ' + data['token']
    refresh_token = data['refreshToken']
    user = data['user']

    try:
        username = user['name']
    except:
        username = user['email'].split('@')[0]
    print("home page value",config['viewerPage'],redirect_uri)
    res = make_response(redirect(config['viewerPage'], 302))
    res.set_cookie('dAT', access_token, max_age=None, path='/')
    res.set_cookie('dRT', refresh_token, max_age=None, path='/')
    res.set_cookie('user', username, max_age=None, path='/')
    return res


@app.route("/logout")
@authenticate
def logout():
    token = request.cookies.get('dRT')
    out = requests.put(config['oauthServerIp'] + '/auth/signOut',
        headers={
            'Authorization': token,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
    )
    out = out.content.decode('utf-8')
    res = make_response(redirect(config['loginPage'], 302))
    res.set_cookie('dAT', '', path='/', expires=0)
    res.set_cookie('dRT', '', path='/', expires=0)
    res.set_cookie('user', '', path='/', expires=0)
    return res


@app.route("/user")
@authenticate
def check():
	user = request.cookies.get('user')
	return user

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5858, debug=True,threaded=True)