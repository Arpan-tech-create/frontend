
from jwt import decode

class TokenVerify:
    def __init__(self, key_file_path='pub.pem'):
        self.key_file = key_file_path
        self.key = open(self.key_file, 'r').read()

    def decode(self, token, verify=True):
        if token is None:
            return None
        parts = token.split(' ')
        if len(parts) != 2:
            print('Invalid len')
            return None
        if parts[0] != 'Bearer':
            print('Invalid id')
            return None
        try:
            print(parts[1])
            decoded = decode(parts[1], key=self.key, verify=False)
        except Exception as e:
            print('Verify failed')
            return None
        return decoded


# bearer = 'Bearer eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxMzhlMzA3OS0xZjI5LTRlNTAtOTljMC1jZGI5OTgzNDZiMzIiLCJpYXQiOjE1ODI4Nzk3MjMsImV4cCI6MTU4Mjg4MTUyM30.LyLkwdMag4_ZyCFsZc11jl64x2074u3-ht0bxoVpTBRmN77_fusbS7d_uNjQ5YmZx12pbhppZeAkDRELca7DpMMOmUa9-6sTxhmUhKe-r8D2r67aOQPV21vVPW-n1bJ7ViJpqyrhEyx06C5zRtG0dRUB28MdiSnMT0S3uYtXFeuGEwzm1vcXq_4-UggXlPP7IJ_-57VV1eldvo7-C4x_VnLnSPC3hRuiGUs2XF_YzzENLGDson-w2MgW0T625nrPvMpiryd8Uc_JPrRsibrlHZ8VUHxDQGAIfdgMRFrbKwGSBKDfj_aCVW68wwaKtewuEtwTcvBJvFtk6z1G6g0vwA'
# verifier = TokenVerify(key_file_path='E:\\arpit\\accessSystem\\src\\main\\resources\\pub.pem')
# print(verifier.decode(bearer, verify=True))

