var fieldDataConstraintDefaults = {
  minLength: null, // For text type
  maxLength: null, // For text type
  inValidCharacters: [], // For text type
  inValidCharactersInput: "",
  photosCount: 1, // For photo type
  minPhotosRequired: 0, // For photo type
  min: null, // For integer type
  max: null, // For integer type
  default: null, // For integer type
  mindec: undefined, // For decimal type
  maxdec: undefined, // For decimal type
  precision: 2, // For decimal type
  defaultdec: undefined, // For decimal type
  isTimeRequired: false, // For timestamp type
  previousDays: null, // For timestamp type
  futureDays: null, // For timestamp type
  minDate: null, // For timestamp type
  maxDate: null, // For timestamp type
  defaultDate: "", // For timestamp type
  defaulttime: "", // For timestamp type
  isRequired: false,
  isMultiSelectAllowed: false,
};
var app = new Vue({
  el: "#app",
  delimiters: ["${", "}"],
  data: {
    accessToken: "",
    refreshToken: "",
    projectList: [],
    searchQuery: "",
    showUserRoleTable: false,
    userRoles: [],
    projectName: "",
    selectedProjectTitle: "",
    usercount:0,
    selectuserdata:0,
    isUserModalOpen: false,
    users: "",
    selectedRole: "admin",
    userFound: false,
    userIds: [],
    enteredUsers: [], // To
    editUserDetails: null,
    showModal: false,
    selectprojectmodal:false,
    showField: false,
    newProject: {
      name: "",
      access: "PRIVATE",
      allowedGeometries: ["point"],
      serviceVersion: 2,
    },
    fieldData: fieldDataConstraintDefaults,
    modalTitle: "",
    modalAction: "Save Project",
    field: "",
    fieldAction: "",
    addedFields: [],
    optionBtn: false,
    showcustomalert:false,
    customalertmessage:""
  },

  methods: {
    //project code

    fetchAddedFieldsFromLocalStorage() {
      const storedFields = localStorage.getItem("addedFields");
      this.addedFields = storedFields ? JSON.parse(storedFields) : [];
    },


    async fetchProjectList() {
      await validateAccessToken(this.accessToken, this.refreshToken);
      const url = "https://vedas.sac.gov.in/udc/schema/list?serviceVersions=2";

      let data = await getRequest(url, this.accessToken);
      this.projectList = data

   
        .filter((item) => item.role === "admin")
        .map((item) => ({
          ...item,
          lastModifiedOn: new Date(item.lastModifiedOn).toLocaleString(),
        }));
        console.log("PROJECT",data);
    },

    
    async fetchProjectDetails(projectId) {
      try {
        const project = this.projectList.find(item => item.id === projectId);
        console.log("fetched Project",project)
    
        if (project) {
          this.selectedProjectTitle = project.name;
          console.log("Clicked Project", this.selectedProjectTitle);
         // await this.fetchUserDetails(projectId);
          //this.showUserRoleTable = false;
        
     // const redirectUrl = `https://vedas.sac.gov.in/sangrahi_project_management/data?projectId=${projectId}&projectName=${this.selectedProjectTitle}`;
   
      const redirectUrl = `https://vedas.sac.gov.in/sangrahi_project_management/data?projectId=${projectId}`;
 
    
          window.open(redirectUrl, '_blank');
        }
      } catch (error) {
        console.error("Error handling project click:", error);
      }
    }
    
,



    async openProjectEditor(mode, project = null) {
      this.showModal = true;
      this.modalTitle = mode === "new" ? "New Project" : "Edit Project";
      this.modalAction = mode === "new" ? "Save Project" : "Update Project";
      if (mode === "edit" && project) {
        await validateAccessToken(this.accessToken, this.refreshToken);
        const url = `https://vedas.sac.gov.in/udc/schema/${project.id}`;

        let data = await getRequest(url, this.accessToken);
        console.log("Data in open project editaor", data);
        this.addedFields = data.fields;

        this.newProject = {
          id: project.id,
          name: project.name,
          access: project.access,
          allowedGeometries: project.allowedGeometries,
          serviceVersion: 2,
        };
      } else {
        this.addedFields = [];
        this.resetProjectDetails();
      }
    },
    closeProjectModal() {
      this.showModal = false;
      this.resetProjectDetails();
      this.clearAddedFields();
      this.selectprojectmodal=false;
    },
    //Field Code
    addOptionsTextBox() {
      if (!this.fieldData.options) {
        this.$set(this.fieldData, "options", []);
      }
      this.optionBtn = true;
      this.fieldData.options.push("");
    },
    resetProjectDetails() {
      this.newProject = {
        name: "",
        access: "PRIVATE",
        allowedGeometries: ["point"],
        serviceVersion: 2,
      };
    },
    closefield() {
      this.showField = false;
      this.resetFieldEditor();
      this.showModal = true;
    },

    clearAddedFields() {
      this.addedFields = [];
    },
    resetFieldEditor() {
      this.fieldData = {
        name: "",
        type: "Text",
        options: [],
        constraints: fieldDataConstraintDefaults,
      };
    },
    openFieldEditor(mode, datafield = null) {
      this.showField = true;
      this.showModal = false;
      this.field = mode === "new" ? "Add Field" : "Edit Field";
      this.fieldAction = mode === "new" ? "Save Field" : "Update Field";

      if (mode === "update" && datafield) {
        this.fieldToUpdateIndex = this.addedFields.findIndex(
          (field) => field.name === datafield.name
        );
        if (this.fieldToUpdateIndex !== -1) {
          this.fieldData = {
            name: datafield.name,
            type: datafield.type,
            options: [...datafield.options],
            constraints: {
              minLength: datafield.constraints?.minLength || null, // For text type
              maxLength: datafield.constraints?.maxLength || null, // For text type
              inValidCharacters: datafield.constraints?.inValidCharacters || [], // For text type
              inValidCharactersInput:
                datafield.constraints?.inValidCharacters?.join("") || "", // For text type
              default: datafield.constraints?.default || null, // For text type
              photosCount: datafield.constraints?.photosCount || null, // For photo type
              minPhotosRequired: datafield.constraints?.minPhotosRequired || 0, // For photo type
              min: datafield.constraints?.min || null, // For integer type
              max: datafield.constraints?.max || null, // For integer type
              precision: datafield.constraints?.precision || 0, // For decimal type
              isTimeRequired: datafield.constraints?.isTimeRequired || false, // For timestamp type
              previousDays: datafield.constraints?.previousDays || null, // For timestamp type
              futureDays: datafield.constraints?.futureDays || null, // For timestamp type
              minDate: datafield.constraints?.minDate || null, // For timestamp type
              maxDate: datafield.constraints?.maxDate || null, // For timestamp type
              isRequired: datafield.constraints?.isRequired || false,
              isMultiSelectAllowed:
                datafield.constraints?.isMultiSelectAllowed || false,
            },
          };
        } else {
          console.error("Field not found for update:", datafield);
          this.resetFieldEditor();
        }
      } else {
        this.resetFieldEditor();
      }
    },
    async saveProjectDetails() {
      // if (!token) {
      //   console.error("Token not found in cookie.");
      //   return;
      // }

      if (!this.newProject.name.trim()) {
        // Project name validation
        this.customAlertMessage = "Project name cannot be empty.";
        this.showcustomalert=true;
        return;
      }
      await validateAccessToken(this.accessToken, this.refreshToken);
      const url = this.newProject.id
        ? `https://vedas.sac.gov.in/udc/schema/${this.newProject.id}`
        : "https://vedas.sac.gov.in/udc/schema/";

      let data = await postRequest(url, this.accessToken, {
        name: this.newProject.name,
        access: this.newProject.access,
        allowedGeometries: this.newProject.allowedGeometries,
        fields: this.addedFields.map((field) => {
          return this.viewModelToDTO(field);
        }),
        serviceVersion: 2,
      });

      console.log("Data is", data);

      if (
        data.status == 400 &&
        data.message.toLowerCase() ==
          "Project with this name already exists".toLowerCase()
      ) {
        this.customAlertMessage = "Project with this name already exists";
        this.showcustomalert=true;
      } else {
        if (data) {
          this.clearAddedFields();
          this.closeProjectModal();
          this.showField = false;
        }
        document.cookie = "dRT=" + this.refreshToken;
        location.reload();
      }
    },
    async deleteProject(id) {
      try {
        // Confirmation alert before deleting the project
        const confirmation = confirm("Are you sure to delete this project?");
        if (!confirmation) {
          return; // If the user cancels, do not proceed with deletion
        }
        await validateAccessToken(this.accessToken, this.refreshToken);
        const url = `https://vedas.sac.gov.in/udc/schema/delete/${id}`;
        const response = await getRequest(url, this.accessToken);
      } catch (error) {
        console.error("Error deleting project:", error);
      }
      document.cookie = "dRT=" + this.refreshToken;
      location.reload(); // Reloading the page after deletion
    },
    deleteField(index) {
      const confirmation = confirm("Are you sure to delete this Field?");
      if (!confirmation) {
        return;
      }
      this.addedFields.splice(index, 1);
      localStorage.setItem("addedFields", JSON.stringify(this.addedFields));
    },

    viewModelToDTO(field) {
      console.log("Calling viewModel");
      let constraints = {};

      if (field.type === "Text") {
        if (field.constraints && !field.constraints.inValidCharactersInput) {
          field.constraints.inValidCharacters = "";
        }

        if (Array.isArray(field.constraints.inValidCharactersInput)) {
          field.constraints.inValidCharactersInput =
            field.constraints.inValidCharactersInput.join("");
        }

        constraints = {
          minLength: field.constraints?.minLength || null,
          maxLength: field.constraints?.maxLength || null,
          inValidCharacters:
            field.constraints?.inValidCharactersInput.split("") || [],
          inValidCharactersInput:
            field.constraints?.inValidCharactersInput || "",
          default: field.constraints?.default || null,
        };
      } else if (field.type === "Photo") {
        constraints = {
          photosCount: field.constraints?.photosCount || null,
          minPhotosRequired: field.constraints?.minPhotosRequired || 0,
        };
      } else if (field.type === "Integer") {
        constraints = {
          min: field.constraints?.min || null,
          max: field.constraints?.max || null,
          default: field.constraints?.default || null,
        };
      } else if (field.type === "Decimal") {
        constraints = {
          min: field.constraints?.min || null,
          max: field.constraints?.max || null,
          precision: field.constraints?.precision || null,
          default: field.constraints?.default || null,
        };
      } else if (field.type === "Timestamp") {
        constraints = {
          isTimeRequired: field.constraints?.isTimeRequired || false,
          previousDays: field.constraints?.previousDays || null,
          futureDays: field.constraints?.futureDays || null,
          minDate: field.constraints?.minDate || null,
          maxDate: field.constraints?.maxDate || null,
          default: field.constraints?.default || null,
        };
      } else if (field.type === "Options") {
        constraints = {
          isMultiSelectAllowed:
            field.constraints?.isMultiSelectAllowed || false,
          default: field.constraints?.default || null,
        };
      }

      constraints["isRequired"] = field.constraints?.isRequired || false;

      return {
        type: field.type,
        name: field.name,
        options: field.options,
        constraints: constraints,
      };
    },
    alertMsgOnFieldError(objectToBePushed) {
      if (
        this.fieldData.type === "Text" &&
        objectToBePushed.constraints.minLength !== null &&
        objectToBePushed.constraints.maxLength !== null &&
        objectToBePushed.constraints.minLength >
          objectToBePushed.constraints.maxLength
      ) {
        alert(" Minimum Length  can not be bigger than Maximum Length ");
        return false; // Prevent further execution
      } else if (
        this.fieldData.type === "Photo" &&
        objectToBePushed.constraints.photosCount !== null &&
        objectToBePushed.constraints.minPhotosRequired !== null
      ) {
        if (
          objectToBePushed.constraints.photosCount <
          objectToBePushed.constraints.minPhotosRequired
        ) {
          alert(
            " Maximum Photos Count can not be smaller than Minimum Photos Count "
          );
          return false; // Prevent further execution
        }
        if (
          objectToBePushed.constraints.minPhotosRequired >
          objectToBePushed.constraints.photosCount
        ) {
          alert(
            "Minimum Photos Count  can not be greater than Maximum Photos Count!"
          );
          return false; // Prevent further execution
        }
      } else if (
        this.fieldData.type === "Integer" &&
        objectToBePushed.constraints.min !== null &&
        objectToBePushed.constraints.max !== null &&
        objectToBePushed.constraints.min > objectToBePushed.constraints.max
      ) {
        alert(" Minimum values  can not be bigger than Maximum values ");
        return false; // Prevent further execution
      } else if (
        this.fieldData.type === "Decimal" &&
        objectToBePushed.constraints.min !== null &&
        objectToBePushed.constraints.max !== null &&
        objectToBePushed.constraints.min > objectToBePushed.constraints.max
      ) {
        alert(" Minimum values  can not be bigger than Maximum values ");
        return false; // Prevent further execution
      } else if (
        this.fieldData.type === "Timestamp" &&
        objectToBePushed.constraints.minDate !== null &&
        objectToBePushed.constraints.maxDate !== null &&
        objectToBePushed.constraints.minDate >
          objectToBePushed.constraints.maxDate
      ) {
        alert(" Minimum Date  can not be bigger than Maximum Date ");
        return false; // Prevent further execution
      } else if (
        this.fieldData.type === "Options" &&
        !this.fieldData.constraints.default &&
        this.fieldData.constraints.isRequired
      ) {
        alert("Please select a default option.");
        return false;
      }
      return true;
    },

    validateAndSaveFields() {
      console.log("Calling update feild ");
      if (!this.fieldData.name.trim()) {
        // Alert the user that field name is required
       // alert("Field name is required!");
        this.showcustomalert=true;
        return; // Prevent form submission
      }
      if (this.fieldData.name && this.fieldData.type) {
        let objectToBePushed = {
          name: this.fieldData.name,
          type: this.fieldData.type,
          options: this.fieldData.options || [],
          constraints: {},
        };
        console.log(
          "Object to b e pushed is",
          objectToBePushed,
          this.fieldAction
        );
        if (this.fieldAction === "Save Field") {
       
          
          
          const existingFieldIndex = this.addedFields.findIndex(
            (field) => field.name === this.fieldData.name

          );
          if (existingFieldIndex !== -1) {
            alert("Field name already exists! Please Provide Different Field Name.");
            return; // Prevent adding a duplicate field
          }

          if (existingFieldIndex !== -1) {
            
            this.$set(this.addedFields, existingFieldIndex, {
              name: this.fieldData.name,
              type: this.fieldData.type,
              options: this.fieldData.options || [],
            });
          } else {
            // Set constraints based on field type
            objectToBePushed = this.viewModelToDTO(this.fieldData);
            if (this.alertMsgOnFieldError(objectToBePushed)) {
              this.addedFields.push(objectToBePushed);
            } else {
              return;
            }
          }
        } else if (
          this.fieldAction === "Update Field" &&
          this.fieldToUpdateIndex !== undefined
        ) {
          objectToBePushed = this.viewModelToDTO(this.fieldData);
          console.log("Constrainst in obj", objectToBePushed);
          if (this.alertMsgOnFieldError(objectToBePushed)) {
            console.log("Return successully", objectToBePushed);
            this.$set(
              this.addedFields,
              this.fieldToUpdateIndex,
              JSON.parse(JSON.stringify(objectToBePushed))
            );
          } else {
            return;
          }
        }

        this.resetFieldEditor();
        localStorage.setItem("addedFields", JSON.stringify(this.addedFields));
        this.closefield();
        //Save field data to local storage
        localStorage.setItem("addedFields", JSON.stringify(this.addedFields));
      }
    },

    //User Code
    async fetchUserDetails(id) {
      try {
        await validateAccessToken(this.accessToken, this.refreshToken);
        let url = `https://vedas.sac.gov.in/udc/schema/findRoles/${id}`;
        let rolesData = await getRequest(url, this.accessToken);
        console.log("roles data",rolesData)


        rolesData.data.forEach(role => {
          console.log(`User: ${role.user}`);
        });   //extract username
       
        let userrole=rolesData.data.length
        this.usercount=userrole
        console.log("COUNT",this.usercount)

        const schemaId = rolesData.data[0].schema;
        console.log(`Number of roles fetched: ${rolesData.data.length}`);
        const projectUrl = `https://vedas.sac.gov.in/udc/schema/${schemaId}`;
        const projectData = await getRequest(projectUrl, this.accessToken);
        this.projectName = projectData.name;

        this.userRoles = rolesData.data;

        this.showUserRoleTable = true;
      } catch (error) {
        console.error("Error fetching person data:", error);
      }
    },

    async openUserDetailsModal(id) {
      this.selectedDatasetId = id;
      await this.fetchUserDetails(id);
    },

    openAddUserEditor(userDetails) {
      this.isUserModalOpen = true;
      this.showUserRoleTable = false;
      // If userDetails are provided, populate the input fields with them
      if (userDetails) {
        this.editUserDetails = userDetails;
        this.users = userDetails.user;
        this.selectedRole = userDetails.role;
      } else {
        this.editUserDetails = null;
        this.users = ""; // Reset the input fields if userDetails is not provided
        this.selectedRole = "admin"; // Set default role
      }
    },
    closeAddUserEditor() {
      this.isUserModalOpen = false;
      this.showUserRoleTable = true;
      this.editUserDetails = null; // Reset editUserDetails
    },
    async saveUserDetails() {
      // Extracting emails from the input
      const emailList = this.editUserDetails
        ? [this.editUserDetails.user]
        : this.users.split(",").map((email) => email.trim());
      const payload = emailList;

      // Requesting user data

      try {
        await validateAccessToken(this.accessToken, this.refreshToken);
        let userUrl = "https://vedas.sac.gov.in/access/users/findByUsername/";
        const userData = await postRequest(userUrl, this.accessToken, payload);
        if (!userData) {
          throw new Error("Network response was not ok");
        }

        this.userFound = false;
        this.enteredUsers = [];
        this.userIds = []; // Reset user IDs

        if (userData && userData.data && userData.data.length > 0) {
          userData.data.forEach((profile) => {
            this.userFound = true;
            this.enteredUsers.push(profile.username);
            this.userIds.push(profile.uidx);
          });
        }

        // Proceeding with the submission if users are found
        if (this.userFound) {
          this.showUserRoleTable = true;
          this.isUserModalOpen = false;
          const schema = this.userRoles[0].schema;

          const payload = {
            schema: schema,
            userIds: this.userIds,
            role: this.selectedRole,
          };
          await validateAccessToken(this.accessToken, this.refreshToken);
          let addUrlUrl = "https://vedas.sac.gov.in/udc/schema/addusers";
          const data = await postRequest(addUrlUrl, this.accessToken, payload);

          if (!data) {
            throw new Error("Network response was not ok");
          }

          await this.fetchUserDetails(this.selectedDatasetId);
        } else {
          alert("User Not Found!!");
        }
      } catch (error) {
        console.error("There was a problem with the fetch operation:", error);
      } finally {
        this.users = "";
      }
    },
    async deleteUser(schema, username) {
      const deleteUserUrl = `https://vedas.sac.gov.in/udc/schema/removeusers`;

      try {
        await validateAccessToken(this.accessToken, this.refreshToken);
        let url = "https://vedas.sac.gov.in/access/users/findByUsername/";
        const uidjson = await postRequest(url, this.accessToken, [username]);
        const result = await postRequest(deleteUserUrl, this.accessToken, {
          schema,
          userIds: [uidjson.data[0].uidx],
        });

        if (
          result.status &&
          result.status.code === 200 &&
          result.status.status === "SUCCESS"
        ) {
          const confirmation = confirm("Are you sure to delete this User?");
          if (!confirmation) {
            return; // If the user cancels, do not proceed with deletion
          }
          this.userRoles = this.userRoles.filter(
            (userRole) => userRole.user !== username
          );
        } else {
          console.error("Error removing user:", result.status.message);
        }
      } catch (error) {
        console.error("Error removing user:", error);
      }
      this.showUserRoleTable = true;
    },
  },


  async mounted() {
    this.refreshToken = localStorage.getItem("dRT");
    if (!this.refreshToken) {
      this.refreshToken = await getCookie("dRT");
    }
    console.log("Refresh token", this.refreshToken);

    if (!this.refreshToken) {
      window.location.href =
        "https://vedas.sac.gov.in/sangrahi_project_management/";
    }

    setToken("dRT", this.refreshToken);

    deleteCookies();

    await setAccessToken(this.refreshToken);
    this.accessToken = getToken("dAT");
    await validateAccessToken(this.accessToken, this.refreshToken);

    if (!this.accessToken) {
      console.error("Token not found in cookie.");
      return;
    }

    this.fetchAddedFieldsFromLocalStorage();
    this.fetchProjectList();
  },
  computed: {
    // Compute unique users from enteredUsers
    uniqueUsers() {
      return Array.from(new Set(this.enteredUsers));
    },
    filteredDatasets() {
      return this.projectList.filter((dataset) => {
        return dataset.name
          .toLowerCase()
          .includes(this.searchQuery.toLowerCase());
      });
    },
    filteredAndSortedProjectList() {
      return this.filteredDatasets.sort((a, b) => {
        // Assuming you want to sort by lastModifiedOn
        return new Date(b.lastModifiedOn) - new Date(a.lastModifiedOn);
      });
    },
  },
  watch: {
    watch: {
      "fieldData.options": {
        handler(newOptions) {
          if (
            newOptions.length > 0 &&
            !newOptions.includes(this.fieldData.constraints.default)
          ) {
            this.fieldData.constraints.default = newOptions[0];
          }
        },
        deep: true,
      },
    },
  },
});
