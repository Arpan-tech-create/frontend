function getCookie(cookieName) {
  const cookies = document.cookie.split("; ");
  console.log("Cookie Details mounted::", cookies);

  for (let i = 0; i < cookies.length; i++) {
    const cookie = cookies[i];
    const [name, value] = cookie.split("=");

    const trimmedName = name.trim();

    if (trimmedName === cookieName) {
      const decodedValue = decodeURIComponent(value);

      const withoutBearer = decodedValue.startsWith("Bearer ")
        ? decodedValue.slice(7)
        : decodedValue;

      const withoutQuotes =
        withoutBearer.startsWith('"') && withoutBearer.endsWith('"')
          ? withoutBearer.slice(1, -1)
          : withoutBearer;

      return withoutQuotes;
    }
  }

  return null;
}
function deleteCookies() {

  console.log("Delete cookies are calling");
  
  document.cookie = "dRT=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  document.cookie = "dAT=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  document.cookie =
    "user" + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";


  console.log("Document cookies are", document.cookie);
}
async function setAccessToken(refreshToken) {
  try {
    let url = "https://vedas.sac.gov.in/access/auth/refresh";
    let response = await postRequest(url, refreshToken, { method: "POST" });
    console.log("Data from refresh URL:", response);

    if (response && response.data && response.data.token) {
      let accessToken = response.data.token;
      console.log("New access token:", accessToken);
      localStorage.setItem("dAT", "Bearer " + accessToken);
      app.accessToken = accessToken;
    } else {
      console.error("Failed to retrieve access token from response:", response);
      logout();
    }
  } catch (error) {
    console.error("Error setting access token:", error);
  }
}

async function validateAccessToken(accessToken, refreshToken) {
  try {
    console.log("Access token is", accessToken);
    let splittedData = accessToken.split(".");
    let payload = splittedData[1];

    let decodedPayload = atob(payload);
    console.log("Decoded payload", decodedPayload);
    decodedPayload = JSON.parse(decodedPayload);
    console.log("Parsed payload", decodedPayload);
    let expiry = decodedPayload.exp;
    expiry = parseInt(expiry) * 1000;
    let currentTime = Date.now();
    console.log("Current time ", currentTime, expiry, expiry - currentTime);
    let timeToExpire = expiry - currentTime;
    console.log("Time to expiry", timeToExpire);

    if (timeToExpire <= 60000) {
      await setAccessToken(refreshToken);
      console.log("Access token refreshed successfully");
    }
  } catch (error) {
    console.error("Error validating access token:", error);
  }
}


async function setToken(name, value) {
  localStorage.setItem(name, value);
}

function getToken(name) {
  return localStorage.getItem(name);
}

async function getRequest(url, token) {
  let response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
    },
  });

  let data = await response.json();
  return data;
}

async function postRequest(url, token, body) {
  let response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: token,
    },
    body: body ? JSON.stringify(body) : "",
  });

  let data = await response.json();
  return data;
}

function logout() {

  localStorage.clear();
 
  deleteCookies();

  // document.cookie = "dRT=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  window.location.href =
    "https://vedas.sac.gov.in/sangrahi_project_management/";
  console.log("Window history", window.history);

  if('caches' in window){
    caches.keys().then(function(keyList){
      return Promise.all(keyList.map(function(key){
        return caches.delete(key);
      }));
    })
  }
}

function redirectToDownloadApp() {
  window.open("https://vedas.sac.gov.in/vstatic/sangrahi_apk/sangrahi.apk");
}

function redirectToViewer() {
  var app = "https://vedas.sac.gov.in/vstatic/sangrahi_viewer/index.html";
  window.open(app, "_blank");
}
