constraints: {
    minLength: null, // For text type
    maxLength: null, // For text type
    inValidCharacters: [],
    inValidCharactersInput: "", // For text type
    default: null, // For text type
    photosCount: 1, // For photo type
    minPhotosRequired: 0, // For photo type
    min: null, // For integer type
    max: null, // For integer type
    precision: 2, // For decimal type
    //defaultdec: undefined,          // For decimal type
    isTimeRequired: false, // For timestamp type
    previousDays: null, // For timestamp type
    futureDays: null, // For timestamp type
    minDate: null, // For timestamp type
    maxDate: null, // For timestamp type
    // defaultDate: '',        // For timestamp type
    //defaulttime: '',
    isRequired: false,
    isMultiSelectAllowed: false,
  },


  generateGeoJson() {
    const table = this.$refs.userTable;
    const rows = table.querySelectorAll('tbody tr');
    const features = Array.from(rows).map(row => {
      const cells = row.querySelectorAll('td');
      console.log("cel",cells)
      return {
        type: 'Feature',
        geometry: {
          type: cells[1].innerText,
          coordinates: [
          cells[3].innerText || 0, 
          cells[3].innerText || 0  
          ],
        },
        properties: {
      

          timestamp: cells[2].innerText,
          photos: cells[4].innerText,
          attributes: cells[5].innerText,
        },
      };
    });

    const geoJson = {
      type: 'FeatureCollection',
      features: features,
    };

    const blob = new Blob([JSON.stringify(geoJson, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'user_data.geojson';
    a.click();

    
    URL.revokeObjectURL(url);
  },
  

  generateGeoJson() {
  
    if(!this.selectedItem){
      console.log("no item")
    
    return;

  }

  const latitude=this.selectedItem.data.Latitude;
  const longitude=this.selectedItem.data.Longitude;
  const name=this.selectedItem.data.Name

  const geoJson={
    features:[
      {
        type:'Features',
        geometry:{
          type:'point',
          coordinates:[longitude,latitude]
        },
        properties:{
          name:name,
          accuracy:this.selectedItem.data.Accuracy,
          altitude:this.selectedItem.data.Altitude
        }
      }
    ]
  };

  const geojsonString=JSON.stringify(geoJson,null,2);

  const blob=new Blob([geojsonString],{type:'application/geo+json'});

  const url=URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href=url;
  a.download='project_data.geojson'
  a.style.display='none';
  document.body.appendChild(a);
  a.click();

  URL.revokeObjectURL(url);
  document.body.removeChild(a);

}