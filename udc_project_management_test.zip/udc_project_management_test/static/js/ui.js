
async function refreshToken() {
  var refreshToken = getCookie("dRT");

  console.log("Refresh Token:::", refreshToken);

  if (refreshToken) {
    let url = "https://vedas.sac.gov.in/access/auth/refresh";

    let data = await postRequest(url, refreshToken);
    var accessToken = data.data.token;
    setCookie("dAT", "Bearer " + accessToken, 30);
  }
}




var app=new Vue({
  el: '#app',
  delimiters: ["${", "}"],
  data: {
    projectName: '',
    projectId: null,
    refresh_token: "",
    access_token: "",
    getcookieshow: false,
    data_count:0,
    user_count:0,
    username:'',
    role:'',
    userRoles:[],

    project_data:[],
    collecteddata_for_user:[],
    filteredData:[],
    isfilterapply:false,
    currentRecord: {},
    feature_type:'',
    timestamp:'',
    imageUrl:'',
    showModal: false,
    filtertype:'',
        selectfiltertype:'calendar',
        filters:{
          fromTimestamp: '',
          toTimestamp: '',
        },
    showcustomalert:false,
    searchingdata:[],
    operation:'',
    operation_value:'',
    propertiesPanelShown: false,
    showLightbox: false,
    ramarkpanelshown:false,
    latitude: '',     
    longitude: '',     
    altitude: '',     
    accuracy: '',     
    timestamp: '' ,
    images:[],
    selectedRole:'all',
    selectedfiltertype:'',
    userdetails:[],
    selectedProject: {},
    schema: {} ,
    featureProperties: {},
    showdata:false,
    clearbutton:true,
    currentImageIndex: 0,
    searchQueryforuser: '',
    searchQueryforuserdata:'' 
  },
  created() {
    this.projectId = this.getQueryParam('projectId');
    console.log("project id : ",this.projectId)
    if (this.projectId) {
      this.fetchProjectName();
      this.fetchProjectData(this.projectId);
      this.fetchUserCounts(this.projectId)
   


     
  
    }
  },

  async mounted() {

    this.filteredData=this.project_data;

    var refresh_token = getCookie("dRT");
    this.refresh_token = refresh_token;
    console.log("refresh_token", refresh_token);
    if (refresh_token) {
      localStorage.setItem("dRT", refresh_token);
      await this.setAccessToken();

      this.getcookieshow = true;
    } else {
      this.getcookieshow = false;
    }
    setInterval(this.setAccessToken, 30 * 1000);
  },

  computed: {
    filteringUserRoles() {
  
      let filtered = this.userRoles.data;
      
 
      if (this.selectedRole !== 'all') {
        filtered = filtered.filter(item => item.role === this.selectedRole);
      }
      
      if (this.searchQueryforuser) {
        filtered = filtered.filter(item => 
          item.user.toLowerCase().includes(this.searchQueryforuser.toLowerCase()) ||item.role.toLowerCase().includes(this.searchQueryforuser.toLowerCase())
        );
      }

      return filtered;
    },

 
    processedProjectData(){
      return this.project_data.map(record=>{
        const userDetail=this.userdetails.find(user=>user.uidx === record.addedBy);
        return{
          ...record,
          username:userDetail?userDetail.username :'Unknown'
        }
      })
    }
   },
  
  
  
   methods: {


    formatDateTime(dateTimeMillis) {
 const date=new Date(dateTimeMillis);
 return date
    },


    async setAccessToken() {
      console.log("Set access token is called");
      let url = "https://vedas.sac.gov.in/access/auth/refresh";
    
      try {
        let data = await postRequest(url, this.refresh_token);
        var accessToken = data.data.token;
    
        if (accessToken && !accessToken.startsWith("Bearer ")) {
          accessToken = "Bearer " + accessToken;
        }
        
        console.log("Access token in set", accessToken);
        this.access_token = accessToken;
        localStorage.setItem("dAT", accessToken);
        // deleteCookie();
    
        return accessToken;
      } catch (error) {
        console.error("Error setting access token:", error);
        throw error;
      }
    },
    getQueryParam(name) {
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get(name);
    },
    async fetchProjectName() {
      try {
        const response = await fetch(`https://vedas.sac.gov.in/udc/schema/${this.projectId}`);
        const data = await response.json();
        console.log("project data : ",data); 

      
        this.schema_name = data.name;
        console.log("NAME OF SCHEMA IS :", this.schema_name);
        this.projectName = data.name || 'No project name found'; 
        console.log("redirected page : ",this.projectName)
  
     
      } catch (error) {
        console.error("Error fetching project name:", error);
        this.projectName = 'Error fetching project name'; 
      }
    },

    async fetchSchema(projectId) {
      const schemaUrl = `https://vedas.sac.gov.in/udc/schema/${projectId}`;
      try {
        const response = await this.fetchData(schemaUrl);
        if (!response || !response.fields) {
          throw new Error('No schema data returned');
        }
        return response;
      } catch (error) {
        console.error('Error fetching schema:', error);
        throw error;
      }
    }
,    
    
    async fetchData(url) {
      let accessToken = localStorage.getItem("dAT");
      
      if (accessToken && !accessToken.startsWith("Bearer")) {
        accessToken = "Bearer " + accessToken;
      }
      
      let opt = {
        method: "GET",
        headers: {
          Authorization: accessToken,
        },
      };
      
      try {
        let dataResponse = await fetch(url, opt);
        
        if (dataResponse.status === 401) {
          console.log("Unauthorized, refreshing token...");
          accessToken = await this.setAccessToken();
          opt.headers.Authorization = accessToken;
          dataResponse = await fetch(url, opt);
        }
        
        if (!dataResponse.ok) {
          throw new Error(`HTTP error! Status: ${dataResponse.status}`);
        }
        
        const contentType = dataResponse.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
          throw new Error("Invalid response format");
        }
        
        const responseData = await dataResponse.json();
        console.log("Fetched data:", responseData);
        return responseData;
    
      } catch (error) {
        console.error("Error making API call:", error);
        throw error;
      }
    },
    isDateString(value) {
      if (typeof value !== 'string' || value.length !== 8) {
          return false;
      }
      const day = value.substring(0, 2);
      const month = value.substring(2, 4);
      const year = value.substring(4, 8);
  
    
      if (!/^\d{8}$/.test(value)) {
          return false;
      }
  
    
      const dayInt = parseInt(day, 10);
      const monthInt = parseInt(month, 10);
      const yearInt = parseInt(year, 10);
  
      // Check if the date is valid
      const date = new Date(yearInt, monthInt - 1, dayInt);
      return date.getFullYear() === yearInt &&
             date.getMonth() === monthInt - 1 &&
             date.getDate() === dayInt;
  },
      isDateUnix(value) {
      return !isNaN(value) && value > 1e9 && value <1e13 && !(/^\d{10}$/.test(value));;
  },

  convertUnixTimestamp(value){

    const timestampInSeconds=value>1e10 ? value/1000 :value;
    return new Date(timestampInSeconds * 1000).toLocaleDateString();
  },
 

async fetchProjectData(projectId) {
  const dataUrl = `https://vedas.sac.gov.in/udc/data/${projectId}`;

  try {
    const dataResponse = await this.fetchData(dataUrl);
    console.log("DATASSSS",dataResponse)

    if (!dataResponse || !dataResponse.data || !Array.isArray(dataResponse.data)) {
      throw new Error('No data returned from fetchData or data is not an array');
    }

    const uniqueAddedby=[...new Set(dataResponse.data.map(record=>record.addedBy))];
    console.log("all unique uidx",uniqueAddedby);

    const userdetails=await this.fetchuserByUIDX(uniqueAddedby);

    this.userdetails=userdetails.data || [];

    console.log("User Details:",this.userdetails);


    this.$set(this,'project_data',this.project_data.map(record=>{
      const userDetail=this.userdetails.find(user=>user.uidx === record.addedBy);
    
      console.log("record",record);
      console.log("Matched UserDetail",userDetail);

     
      return{
        ...record,
        username:userDetail ? userDetail.username :'Unknown',
      }
    }));


console.log("MAPPED PROJECT DATA",this.project_data);

    console.log("data_API:", dataResponse);

    this.project_data = dataResponse.data;
    console.log("project_data in api",this.project_data)
    this.data_count = this.project_data.length;
    console.log("DATA COUNT:", this.data_count);

    if (this.data_count > 0) {
 
      const schema = await this.fetchSchema(projectId);
      console.log("Schema for projectId:", schema);

    
      const imageProperties = schema.fields
        .filter(field => field.type === "Photo" || field.type === "image")
        .map(field => field.name);
      console.log("Image properties:", imageProperties);

   

      this.project_data = this.project_data.map(record => {
        const data = record.data;
        console.log("DATA IN FETCH_PROJECT_DATA",data)
        let images = [];

        imageProperties.forEach(field => {
          let imgId = data[field];
          console.log("image ids",imgId)
          if (imgId) {
            if (Array.isArray(imgId)) {
              imgId = imgId.filter(img => img && img.length > 0);
              if (imgId.length > 0) {
                images.push(...imgId);
                console.log("images  are inserting.....",images)  
              }
            } else {
              images.push(imgId);
            }
          }
        });

        return {
          ...record,
          images,
          latitude: data.Latitude || '',
          longitude: data.Longitude || '',
          altitude: data.Altitude || '',
          accuracy: data.Accuracy || '',
          timestamp: data.DateTime || '',
          additionalData: Object.fromEntries(
            Object.entries(data).filter(([key, value]) => !imageProperties.includes(key))
            .map(([key,value])=>{
              if(this.isDateUnix(value)){
                value=this.convertUnixTimestamp(value);
              }
              return [key,value];
            }
          
          
          )
     
          )
        };
      });

      console.log("Processed project_data with images and other properties:", this.project_data);
    } else {
      console.log("No records found.");
    }

    return dataResponse;

  } catch (error) {
    console.error("Error fetching project data:", error);
    throw error;
  }
  
},


async fetchuserByUIDX(uidxList){

  const userdetailsurl=`https://vedas.sac.gov.in/access/users/findByUidx`;

  try{

    const response=await fetch(userdetailsurl,{

      method:'POST',
      headers:{
        'content-Type':'application/json',
      },

      body:JSON.stringify(uidxList),

    });

    if(!response.ok){
      throw new error('Failed to fetch user details');
    }
    const userdetails=await response.json();
    return userdetails;
  }catch(error){
    console.error("error is here",error);
    throw error;
  }

},


    async fetchUserCounts(projectId) {
      const url = `https://vedas.sac.gov.in/udc/schema/findRoles/${projectId}`;
      
      try {
        const response = await this.fetchData(url);
        
        if (!response || !Array.isArray(response.data)) {
          throw new Error('No data returned from fetchData or data is not an array');
        }
    
        console.log("res:", response);
        
        this.user_count = response.data.length;
        console.log("COUNT OF USERS",this.user_count)
        this.userRoles = response;
        console.log("RESPONSES:", this.userRoles);
        
        return response;
    
      } catch (error) {
        console.error("Error fetching user counts:", error);
        throw error;
      }
    }
    ,

    showUserModal() {
     
      this.users = this.fetchUserCounts(); 
      this.showModal = true;
    },
    showFilterModal(){
      console.log("filter modal opening");
      this.filtertype=true;
      this.clearbutton=false;
    },

 

    openremarkpanel(){
      this.ramarkpanelshown=true;
    },
    
    openPropertiesPanel(item) {
      this.selectedItem = { ...item };
      console.log("in property",this.selectedItem)
   
      this.showdata = true;
   
    },

    closePropertiesPanel() {
      this.showdata = false;
      this.selectedItem = null;
    },
    isDisplayable(key) {
      const excludedKeys = ['Latitude', 'Longitude', 'Altitude', 'Accuracy', 'DateTime', 'location', 'project_name'];
      return !excludedKeys.includes(key);
    },
    closedata() {
      this.showdata = false;
      this.selectedProject = {}; 
    },

    submitremark(){
      console.log("remark submitted");
      this.ramarkpanelshown=false;
    },


    prevImage() {
      if (this.currentImageIndex > 0) {
        this.currentImageIndex--;
      } else {
        this.currentImageIndex = this.selectedItem.images.length - 1; 
      }
    },
    nextImage() {
      if (this.currentImageIndex < this.selectedItem.images.length - 1) {
        this.currentImageIndex++;
      } else {
        this.currentImageIndex = 0;
      }
    },



    applyfilter(){
      if(this.selectfiltertype==='calendar'){
        if(!this.filters.fromTimestamp || !this.filters.toTimestamp){
          this.showcustomalert=true;
          return;
        }
        const fromTimestamp=new Date(this.filters.fromTimestamp);
        const toTimestamp=new Date(this.filters.toTimestamp);
        
      this.filteredData=this.project_data.filter(item => {
        console.log("it",item)


        const timestamp= new Date(item.data.DateTime);

        return timestamp >=fromTimestamp && timestamp<=toTimestamp;
      });

      this.isfilterapply=true;
     
 
      }
      else{
        this.filteredData=this.project_data;
        console.log("all")
      }

     
      this.clearbutton=true;
      


    },

    clearFilters(){
      this.filters.fromTimestamp='';
      this.filters.toTimestamp='';
      this.filteredData=this.project_data;
      this.isfilterapply=false;
     this.clearbutton=false;
    },


    
    generateExcel() {
      const ws_data = [];
      const header = ['Sr.No', 'Feature Type', 'Timestamp', 'Latitude', 'Longitude', 'Accuracy', 'Altitude'];

      const additionalkeys=Object.keys(this.project_data[0].data)
      .filter(key => !['Latitude', 'Longitude', 'Accuracy', 'Altitude','DateTime','location'].includes(key));
      ws_data.push([...header,...additionalkeys]);

      this.project_data.forEach((item, index) => {
        const row = [
          index + 1,
          item.data.location.type,
          this.formatDateTime(item.data.DateTime),
    
          item.data.Latitude || '',
          item.data.Longitude || '',
          item.data.Accuracy || '',
          item.data.Altitude || '',
         
        ];

        additionalkeys.forEach(key=>{
          row.push(item.data[key]||'')
        });

        ws_data.push(row);
      });

      const ws = XLSX.utils.aoa_to_sheet(ws_data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'User Roles');
      XLSX.writeFile(wb, 'user_data.xlsx');
    }
  ,
    generateGeoJson() {
  
      if(!this.selectedItem){
        console.log("no item")
      
      return;

    }

    const latitude=this.selectedItem.data.Latitude;
    const longitude=this.selectedItem.data.Longitude;
    const name=this.selectedItem.data.Name
    const type1=this.selectedItem.data.location.type

    const geoJson={
      features:[
        {
          type:'Features',
          geometry:{
            type:type1,
            coordinates:[longitude,latitude]
          },
          properties:{
            name:name,
            accuracy:this.selectedItem.data.Accuracy,
            altitude:this.selectedItem.data.Altitude,
            datetime:this.convertUnixTimestamp(this.selectedItem.data.DateTime)
          }
        }
      ]
    };

    const geojsonString=JSON.stringify(geoJson,null,2);

    const blob=new Blob([geojsonString],{type:'application/geo+json'});

    const url=URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href=url;
    a.download='project_data.geojson'
    a.style.display='none';
    document.body.appendChild(a);
    a.click();

    URL.revokeObjectURL(url);
    document.body.removeChild(a);
  
  }
    
 

  }
});