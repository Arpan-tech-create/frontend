from flask import Flask, render_template,jsonify,request

from datetime import datetime,timedelta
import db1
import matplotlib.pyplot as plt


app = Flask(__name__, template_folder='templates')


@app.route('/', methods=['GET'])
def main():

   

  
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    selected_app = request.args.get('app')
  

    if selected_app:
        urls = db1.distinct_urls_by_tag(selected_app,'base_url')
    else:
        urls = []

    if not from_date:
        latest_date = db1.get_latest_date()
        from_date = latest_date - timedelta(days=7)
    if isinstance(from_date, str):
        from_date = datetime.strptime(from_date, '%Y-%m-%d')
    if not to_date:
        to_date = latest_date
    if isinstance(to_date, str):
        to_date = datetime.strptime(to_date, '%Y-%m-%d')


    from_date = from_date.strftime('%Y-%m-%d')
    to_date = (to_date + timedelta(days=1)).strftime('%Y-%m-%d')
    tag_table_bar = db1.get_daily_tag_counts(from_date, to_date)
    tag_count = db1.get_tag_counts_in_date_range('base_url', from_date, to_date)
    application_count_pie_chart = db1.get_tag_counts_in_date_range('referrer', from_date, to_date)
    top_sources_pie_chart = db1.get_tag_counts_in_date_range('domain', from_date, to_date)
    apps = db1.get_distinct_tags('base_url',from_date, to_date)
    distinct_ip, distinct_url, distinct_ref  = db1.get_access_log_counts(from_date, to_date)


    
    
    tag_data = [(row[0].strftime("%d-%b-%Y"), row[1]) for row in tag_table_bar]
    return render_template('dashboard.html', apps=apps, urls=urls,tag_count=tag_count, top_sources_pie_chart=top_sources_pie_chart,
                           application_count_pie_chart=application_count_pie_chart,
                           ip1=distinct_ip, url=distinct_url, ref=distinct_ref,
                           tag_table_bar=tag_data,from_date=from_date,to_date=to_date)








@app.route('/get_hourly_data_for_date', methods=['GET'])
def get_hourly_data_for_date():
    selected_date = request.args.get('date')
    value = request.args.get('value')
   
    if selected_date: 
        conn = db1.connect_to_database()
        if conn:
            query = "SELECT EXTRACT(HOUR FROM timestamp) AS hour, COUNT(*) AS count " \
                    "FROM tags " \
                    "WHERE DATE(timestamp) = %s "

            parameters = (selected_date,)

            if value is not None:
                query += " AND value = %s "
                parameters += (value,)

            query += "GROUP BY hour " \
                     "ORDER BY hour;"

            with conn.cursor() as cur:
                cur.execute(query, parameters)
                
                data = cur.fetchall()
                print(data)

            return jsonify(data)
    
    return jsonify([])

@app.route('/update_tag_date_occurrence')
def update_tag_date_occurrence():

    tag_name=request.args.get("tag_name")
  
    with db1.connect_to_database() as conn:
        if conn:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE value = '"+tag_name+"' and tag_type='base_url' GROUP BY date ORDER BY date;"
            with conn.cursor() as cur:        
                cur.execute(query)
                data=cur.fetchall()
                date_occurrence_data = [(row[0].strftime("%d-%b-%Y"), row[1]) for row in data]
            return jsonify(date_occurrence_data)
        else:
            return jsonify([])
    

@app.route('/update_tag_bar_chart_by_sources')
def tag_by_sources():

    source_name=request.args.get("source_name")

    with db1.connect_to_database() as conn:
        if conn:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE value = '"+source_name+"' and tag_type='domain' GROUP BY date ORDER BY date;"
            with conn.cursor() as cur:
                cur.execute(query)
                data=cur.fetchall()
                tags_date_by_sources=[(row[0].strftime("%d-%b-%Y"),row[1]) for row in data]
            return jsonify(tags_date_by_sources)
        else:
            return jsonify([])
    

@app.route('/update_tag_bar_chart_by_applications')
def tag_by_app():
    

    app_name = request.args.get("app_name")

    with db1.connect_to_database() as conn:
        if conn:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE value = '"+app_name+"' and tag_type ='referrer' GROUP BY date ORDER BY date;"
            with conn.cursor() as cur:
                cur.execute(query)
                data = cur.fetchall()
                tags_date_by_apps = [(row[0].strftime("%d-%b-%Y"), row[1]) for row in data]
                print(tags_date_by_apps)

            return jsonify(tags_date_by_apps)
        else:
            return jsonify([])
        






        
        
@app.route('/get_urls', methods=['GET'])
def get_urls():
    selected_app = request.args.get('app')
 
   
    urls = db1.distinct_urls_by_tag(selected_app,'base_url')
    return jsonify({'urls': urls})



@app.route('/table')
def table_app():
    return render_template('table.html')
if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True, port=5003)