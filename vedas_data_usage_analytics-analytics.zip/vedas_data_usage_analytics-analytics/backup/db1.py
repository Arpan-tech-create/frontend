
import psycopg2
from datetime import datetime,timedelta





def connect_to_database():
    try:
        conn = psycopg2.connect(
            dbname='vedas',
            user='postgres',
            password='sac123',
            host='localhost',
            port='5432'
        )
        return conn
    except psycopg2.Error as e:
        print("Error connecting to the database:", e)
        return None

def execute_query(conn, query,params=None):
    try:
        cur = conn.cursor()
        cur.execute(query, params)
        data = cur.fetchall()
        cur.close()
        return data
    except psycopg2.Error as e:
        print("Error executing query:", e)
        return []

def get_one_week_data_from_database():
    conn = connect_to_database()
    if conn is not None:
        try:
            cursor = conn.cursor()

            # Calculate the end date (current date)
            end_date = datetime.now()

            # Calculate the start date (current date - 7 days)
            start_date = end_date - timedelta(days=7)

            # Execute a query to get data from the last seven days
            cursor.execute("SELECT * FROM access_logs WHERE timestamp BETWEEN %s AND %s", (start_date, end_date))
            one_week_data = cursor.fetchall()

            return one_week_data

        except psycopg2.Error as e:
            print("Error executing query:", e)
        finally:
            cursor.close()
            conn.close()



def get_access_log_counts(from_date=None, to_date=None):  # distinct counts from access_logs(IPs,Referreres,URLs)
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()

        queries = [
            "SELECT COUNT(DISTINCT IP) AS ip FROM access_logs",
            "SELECT COUNT(DISTINCT url) AS url FROM access_logs",
            "SELECT COUNT(DISTINCT referer) AS ref FROM access_logs"
           
        ]

        results = []

        for query in queries:
            if from_date and to_date:
                cursor.execute(query + " WHERE timestamp >= %s AND timestamp <= %s;", (from_date, to_date))
            else:
                cursor.execute(query)

            result = cursor.fetchone()
            results.append(result[0])
     

        cursor.close()
        conn.close()

        return results


def get_daily_tag_counts(from_date=None, to_date=None):  #bar_chart
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor() 

        if from_date and to_date:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE timestamp >= %s AND timestamp <= %s GROUP BY date ORDER BY date;"
            cursor.execute(query, (from_date, to_date))
        else:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags GROUP BY date ORDER BY date;"
            cursor.execute(query)

        data = cursor.fetchall()
        cursor.close()
        conn.close()
        return data



def get_distinct_tags(tag_type,from_date=None,to_date=None):  #apps:base_url_drop_down
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor() 
        if from_date and to_date:
            query="select distinct value from tags where tag_type=%s and timestamp >= %s AND timestamp <= %s"
            cursor.execute(query,(tag_type,from_date,to_date))
        else:
              query="select distinct value from tags where tag_type=%s"
              cursor.execute(query,(tag_type,))

        apps = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return apps
    

def distinct_urls_by_tag(value,tag_type):
    # access tag tag table acess_log_id
    # url
    pass

def get_urls_table_for_app(value, tag_type):
    conn = connect_to_database()  # Assuming you have a function to connect to the database
    
    if conn:
        cursor = conn.cursor() 
        query = """
            SELECT access_logs.url 
            FROM access_logs 
            JOIN tags ON access_logs.id = tags.req_id 
            WHERE tags.tag_type = %s AND tags.value LIKE %s
        """
        cursor.execute(query, (tag_type, f'%{value}%'))
        urls = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return urls


def get_urls_table_for_app(tag_type):
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor() 
        query = "select url from access_logs where url like %s  "
        cursor.execute(query, ('%' + tag_type + '%',))
        urls = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return urls

    

def get_tag_counts_in_date_range(tag_type, from_date=None, to_date=None):   #3 pie_charts(services,applications,sources)
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor()
        if from_date and to_date:
            query = "SELECT value, COUNT(*) AS cnt FROM tags WHERE tag_type = %s AND timestamp >= %s AND timestamp <= %s and value!='vedas.sac.gov.in' and value!='localhost' GROUP BY value ORDER BY cnt DESC LIMIT 15;"
            cursor.execute(query, (tag_type, from_date, to_date))
        else:
            query = "SELECT value, COUNT(*) AS cnt FROM tags WHERE tag_type = %s and value!='vedas.sac.gov.in' and  value!='localhost' GROUP BY value ORDER BY cnt DESC LIMIT 15;"
            cursor.execute(query, (tag_type,))

        top_data = cursor.fetchall()
        cursor.close()
        conn.close()
        return top_data



        




























































































































































































































































































































































































































































































































































