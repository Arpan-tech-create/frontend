import psycopg2
import re
import db
from tag_gen import tag_generators
import gzip
import os
from multiprocessing import Pool
import datetime
import heapq

last_processed_date = datetime.datetime.min


def extract_log_info(log_line):
    pattern = r'^(\d+\.\d+\.\d+\.\d+) - - \[(.*?)\] "\w+ (.*?) HTTP\/\d\.\d" (\d+) (\d+) "(.*?)" "(.*?)"$'
    match = re.match(pattern, log_line)
    if match:
        ip, timestamp, url, response, size, referer, client = match.groups()
        return ip, timestamp, url, int(response), int(size), referer, client
    else:
        return None


def process_gz_file(gz_file, is_async=True):
    global last_processed_date
    file_modification_date = datetime.datetime.fromtimestamp(os.path.getmtime(gz_file))
    print("modify", file_modification_date)

    if file_modification_date > last_processed_date:
        log_file_path = os.path.join(os.path.dirname(gz_file), f"extracted_{os.path.basename(gz_file)[:-3]}")

        with gzip.open(gz_file, 'rb') as f_in, open(log_file_path, 'wb') as f_out:
            f_out.write(f_in.read())
        print(f'Extracted {gz_file} to {log_file_path}')

        with gzip.open(gz_file, 'rt') as f:
            conn = psycopg2.connect(
                dbname='vedas',
                user='postgres',
                password='sac123',
                host='localhost',
                port='5432'
            )

            cursor = conn.cursor()

            for line in f:
                log_info = extract_log_info(line)

                if log_info:
                    log_id = db.insert_log_entry(conn, *log_info)
                    generated_tags = []
                    log_entry_dict = {
                        'id': log_id,
                        'ip': log_info[0],
                        'timestamp': log_info[1],
                        'url': log_info[2],
                        'response': log_info[3],
                        'size': log_info[4],
                        'referer': log_info[5],
                        'client': log_info[6]
                    }
                    for tag_generator in tag_generators:
                        generated_tags.extend(tag_generator([log_entry_dict]))
                    db.insert_tags(conn, generated_tags)

            conn.commit()
            cursor.close()
            conn.close()

        last_processed_date = datetime.datetime.now()

    elif is_async:
     
        print(f'File {gz_file} not processed due to older modification date.')


def process_folder(folder_path, num_files_to_process):
    gz_files = [os.path.join(root, file) for root, dirs, files in os.walk(folder_path) for file in files if file.endswith(".gz")]

    if gz_files:
        most_recent_n_gz_files = heapq.nlargest(num_files_to_process, gz_files, key=os.path.getmtime)
        print(most_recent_n_gz_files)

        with Pool(num_files_to_process) as pool:
      
            [pool.apply_async(process_gz_file, args=(gz_file,)) for gz_file in most_recent_n_gz_files]

            pool.close()
            pool.join()
    else:
        print("No .gz files found.")


if __name__ == '__main__':
    folder_path = 'F:/ARPAN/NGINX_LOGS'
    num_files_to_process = 4  #
    process_folder(folder_path, num_files_to_process)
