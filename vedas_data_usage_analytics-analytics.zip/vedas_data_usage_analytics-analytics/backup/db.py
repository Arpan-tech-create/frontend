def get_access_logs(tag=None,from_date=None,to_date=None): #get_data_from_access_logs
    tag["tag_type"]
    return [{}]


def get_access_log_counts(tag=None,from_date=None,to_date=None):  #4_para
    tag["tag_type"]
    return [{}]


def get_access_log_daily_counts(tag=None,from_date=None,to_date=None):  #date_bar_chart  
    tag["tag_type"]
    return [{}]







