      // JavaScript to handle the preloader
      document.addEventListener('DOMContentLoaded', function() {
        const preloader = document.getElementById('preloader');
        const totalRequests = 1;  // Total number of AJAX requests
        let completedRequests = 0;

        const checkCompletion = () => {
            completedRequests++;
            if (completedRequests === totalRequests) {
                preloader.style.display = 'none';
            }
        };

        // Simulate multiple fetch/AJAX requests
        const fetchData = (url) => {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve();
                    checkCompletion();
                }, 1000); // Simulating network delay
            });
        };

        // Fetch example URLs
        fetchData('http://192.168.2.210:5006/get_latest_date');
 
    });