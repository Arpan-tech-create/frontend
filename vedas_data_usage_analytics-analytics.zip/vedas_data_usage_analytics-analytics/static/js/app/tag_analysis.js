document.addEventListener('DOMContentLoaded', function () {
    const tagTypeDropdown = document.getElementById('tagTypeDropdown');
    const tagValueDropdown = document.getElementById('tagValueDropdown');
    const groupByDropdown = document.getElementById('groupByDropdown');
    const getDataButton = document.getElementById('getDataButton');
    const dataTableContainer = document.getElementById('dataTableContainer');
    const preloader = document.getElementById('preloader');

    const populateTagTypes = (dropdown) => {
        fetch('/get_tag_types')
            .then(response => response.json())
            .then(tagTypes => {
                tagTypes.forEach(tagType => {
                    const option = document.createElement('option');
                    option.value = tagType;
                    option.text = tagType;
                    dropdown.appendChild(option);
                });
            })
            .catch(error => console.error('Error fetching tag types:', error));
    };

    const populateTagValues = (selectedTagType) => {
        tagValueDropdown.innerHTML = '';

        fetch(`/get_tag_values?tag_type=${selectedTagType}`)
            .then(response => response.json())
            .then(tagValues => {
                tagValues.forEach(tagValue => {
                    const option = document.createElement('option');
                    option.value = tagValue;
                    option.text = tagValue;
                    tagValueDropdown.appendChild(option);
                });
            })
            .catch(error => console.error('Error fetching tag values:', error));
    };

    const fetchData = (url, successCallback, errorCallback) => {
        // Show preloader before starting the request
        preloader.style.display = 'block';

        fetch(url)
            .then(response => response.json())
            .then(data => {
                // Hide preloader after successful data fetch
                preloader.style.display = 'none';
                successCallback(data);
            })
            .catch(error => {
                // Hide preloader in case of error
                preloader.style.display = 'none';
                errorCallback(error);
            });
    };

    const displayData = (data, container) => {
        if (data.length === 0) {
            alert('No Match Found!!');
            location.reload();
            return;
        }
        console.log('Data received from server:', data);  // Debugging step
        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Tag Type</th>
                    <th>Tag Value</th>
                    <th>Group By Value</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                ${data.map(row => `
                    <tr>
                        <td>${row.referrer_type}</td>  <!-- referrer_type -->
                        <td>${row.referrer_value}</td>  <!-- referrer_value -->
                        <td>${row.base_url_value}</td>  <!-- base_url_value -->
                        <td>${row.count}</td>  <!-- count -->
                    </tr>
                `).join('')}
            </tbody>
        `;
        container.innerHTML = '';
        container.appendChild(table);
    };

    populateTagTypes(tagTypeDropdown);
    populateTagTypes(groupByDropdown);

    tagTypeDropdown.addEventListener('change', function () {
        const selectedTagType = tagTypeDropdown.value;
        populateTagValues(selectedTagType);
    });

    getDataButton.addEventListener('click', function () {
        const selectedTagType = tagTypeDropdown.value;
        const selectedTagValue = tagValueDropdown.value;
        const selectedGroupBy = groupByDropdown.value;

        const url = `/get_data?tag_type=${selectedTagType}&tag_value=${selectedTagValue}&group_by=${selectedGroupBy}`;

        fetchData(url, data => {
            displayData(data, dataTableContainer);
        }, error => {
            console.error('Error fetching data:', error);
        });
    });
});
