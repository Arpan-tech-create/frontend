from flask import Flask, render_template,jsonify,request
import db1


app = Flask(__name__, template_folder='templates')

@app.route('/', methods=['GET'])
def main():
   
    return render_template('dashboard.html')

@app.route('/tag_analysis')
def tags():
    return render_template('tag_analysis.html')


@app.route('/tag')
def tags1():
    return render_template('tag_analyzer-test.html')


@app.route('/get_tag_types', methods=['GET'])
def get_tag_types():
    try:
        tag_types = db1.get_distinct_tag_type()
        return jsonify(tag_types)

    except Exception as e:
        return jsonify(error=str(e))
    

@app.route('/get_tag_values', methods=['GET'])
def get_tag_value():
    try:
        selected_tag_type = request.args.get('tag_type')
        tag_values = db1.get_tag_values(selected_tag_type)
        return jsonify(tag_values)

    except Exception as e:
        return jsonify(error=str(e))
@app.route('/get_data', methods=['GET'])
def get_data_endpoint():
    tag_type = request.args.get('tag_type')
    tag_value = request.args.get('tag_value')
    group_by = request.args.get('group_by')

    if not tag_type or not tag_value or not group_by:
        return jsonify({'error': 'Missing parameters'}), 400

    data = db1.get_data_query(tag_type, tag_value, group_by)

    if data is None:
        return jsonify({'error': 'Failed to fetch data from the database'}), 500

    result = []
    for row in data:
        result.append({
            'referrer_type': row[0],
            'referrer_value': row[1],
            'base_url_value': row[2],
            'count': row[3]
        })

    return jsonify(result)
    
    
@app.route('/get_application_pie_by_service', methods=['GET'])
def get_data():
    try:
        selected_tag_value = request.args.get('tag_value')
        result_from_db = db1.get_data_for_app_by_service(selected_tag_value)

   

        return jsonify(result_from_db)

    except Exception as e:
        return jsonify(error=str(e))


@app.route('/get_source_pie_by_service',methods=['GET'])
def get_data2():
    try:
        selected_tag_value = request.args.get('tag_value')
        result_from_db = db1.get_data_for_source_by_service(selected_tag_value)

   

        return jsonify(result_from_db)

    except Exception as e:
        return jsonify(error=str(e))

@app.route('/get_service_pie_by_app',methods=['GET'])
def get_data3():

    try:
        selected_tag_value=request.args.get('tag_value')
        results=db1.get_data_for_service_by_app(selected_tag_value)
        return jsonify(results)
    except Exception as e:
        return jsonify(error=str(e))
    
@app.route('/get_source_pie_by_app',methods=['GET'])
def get_data4():

    try:
        selected_tag_value=request.args.get('tag_value')
        results=db1.get_data_for_source_by_app(selected_tag_value)
        return jsonify(results)
    except Exception as e:
        return jsonify(error=str(e))


@app.route('/get_app_pie_by_source',methods=['GET'])
def get_data5():
    try:
        selected_tag_value=request.args.get('tag_value')
        results=db1.get_data_for_app_by_source(selected_tag_value)
        return jsonify(results)
    except Exception as e:
        return jsonify(error=str(e))
    

@app.route('/get_service_pie_by_source',methods=['GET'])
def get_data6():
    try:
        selected_tag_value=request.args.get('tag_value')
        results=db1.get_data_for_service_by_source(selected_tag_value)
        return jsonify(results)
    except Exception as e:
        return jsonify(error=str(e))


    

@app.route('/get_latest_date', methods=['GET'])
def get_latest_date():
    to_date = db1.get_latest_date()
    formatted_to_date = to_date.strftime("%Y-%m-%d")
    return jsonify({'latest_date': formatted_to_date})


@app.route('/get_distinct_application_count', methods=['GET'])
def get_distinct_ip_count_route():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    distinct_ip = db1.get_distinct_application_count(from_date,to_date)
    data = {
        "distinct_ip": distinct_ip,
      }
    
    return jsonify(data)

@app.route('/get_distinct_domain_count', methods=['GET'])
def get_distinct_ref_count_route():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    distinct_referer = db1.get_distinct_domain_count(from_date,to_date)
    data = {
        "distinct_referer": distinct_referer,
      }
   
    return jsonify(data)

@app.route('/get_distinct_service_count', methods=['GET'])
def get_distinct_url_count_route():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    distinct_url = db1.get_distinct_service_count(from_date,to_date)
    data = {
        "distinct_url": distinct_url,
      }
   

    return jsonify(data)

@app.route('/get_daily_tag_counts', methods=['GET'])   #for Daily Occurrence Bar Chart
def daily_tag_counts():
 
  
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
   
    tag_table_bar = db1.get_daily_tag_counts(from_date,to_date)
    tag_data = [(row[0].strftime("%d-%b-%Y"), row[1]) for row in tag_table_bar]
    
    return jsonify(tag_data)



@app.route('/get_tag_counts_service', methods=['GET']) #for top service Pie chart
def tag_cnt_date_range_service():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')

    tag_count = db1.get_tag_counts_in_date_range('base_url',from_date,to_date)
    return jsonify(tag_count)




@app.route('/get_tag_counts_application', methods=['GET'])   #for  Top applications by Requests pie chart
def tag_cnt_date_range_app():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    application_count_pie_chart = db1.get_tag_counts_in_date_range('referrer',from_date,to_date)
   
    return jsonify(application_count_pie_chart)


@app.route('/get_tag_counts_application_by_landing_page', methods=['GET'])   #for  Top applications by Landing Page pie chart
def tag_cnt_landing_date_range_app():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    application_count_landing_page = db1.get_tag_counts_in_date_range('app_entry',from_date,to_date)
    print(application_count_landing_page)
   
    return jsonify(application_count_landing_page)



@app.route('/get_tag_counts_source', methods=['GET'])  #for top sources pie chart
def tag_cnt_date_range_source():
    from_date = request.args.get('from_date')
    to_date = request.args.get('to_date')
    top_sources_pie_chart = db1.get_tag_counts_in_date_range('domain',from_date,to_date)
    return jsonify(top_sources_pie_chart)







@app.route('/get_hourly_data_for_date', methods=['GET'])  #get hourly bar chart by date & selected  values(from 3 piecharts(service,application,source))
def get_hourly_data_for_date():
    selected_date = request.args.get('date')
    value = request.args.get('value')
   
    if selected_date: 
        conn = db1.connect_to_database()
        if conn:
            query = "SELECT EXTRACT(HOUR FROM timestamp) AS hour, COUNT(*) AS count " \
                    "FROM tags " \
                    "WHERE DATE(timestamp) = %s "

            parameters = (selected_date,)

            if value is not None:
                query += " AND value = %s "
                parameters += (value,)

            query += "GROUP BY hour " \
                     "ORDER BY hour;"

            with conn.cursor() as cur:
                cur.execute(query, parameters)
                
                data = cur.fetchall()
                

            return jsonify(data)
    
    return jsonify([])

@app.route('/update_tag_date_occurrence')
def update_tag_date_occurrence():
    tag_name = request.args.get("tag_name")
    from_date = request.args.get("from_date")
    to_date = request.args.get("to_date")
    
    with db1.connect_to_database() as conn:
        if conn:
         
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE value = %s AND tag_type = 'base_url' AND timestamp BETWEEN %s AND %s GROUP BY date ORDER BY date;"

            with conn.cursor() as cur:        
                cur.execute(query,(tag_name,from_date,to_date))
                data = cur.fetchall()
                
             
                date_occurrence_data = [(row[0].strftime("%d-%b-%Y"), row[1]) for row in data]
          
            return jsonify(date_occurrence_data)
        else:
          
            return jsonify([])
    

@app.route('/update_tag_bar_chart_by_sources')    #change of daily barchart by source
def tag_by_sources():

    source_name=request.args.get("source_name")
    from_date = request.args.get("from_date")
    to_date = request.args.get("to_date")

    with db1.connect_to_database() as conn:
        if conn:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE value = %s and tag_type='domain' AND timestamp BETWEEN %s AND %s GROUP BY date ORDER BY date;"
            with conn.cursor() as cur:
                cur.execute(query,(source_name,from_date,to_date))
                data=cur.fetchall()
                tags_date_by_sources=[(row[0].strftime("%d-%b-%Y"),row[1]) for row in data]
                
            return jsonify(tags_date_by_sources)
        else:
            return jsonify([])
    

@app.route('/update_tag_bar_chart_by_applications') #change of daily barchart by application
def tag_by_app():
    

    app_name = request.args.get("app_name")
    from_date = request.args.get("from_date")
    to_date = request.args.get("to_date")
    with db1.connect_to_database() as conn:
        if conn:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE value = %s and tag_type='referrer' AND timestamp BETWEEN %s AND %s GROUP BY date ORDER BY date;"
            with conn.cursor() as cur:
                cur.execute(query,(app_name,from_date,to_date))
                data = cur.fetchall()
                tags_date_by_apps = [(row[0].strftime("%d-%b-%Y"), row[1]) for row in data]
                

            return jsonify(tags_date_by_apps)
        else:
            return jsonify([])

        

        


if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True, port=5006)