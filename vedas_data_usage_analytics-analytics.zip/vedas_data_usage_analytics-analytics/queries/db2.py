from flask import Flask, render_template,jsonify
import psycopg2

app = Flask(__name__, template_folder='templates')

def connect_to_database():
    try:
        conn = psycopg2.connect(
            dbname='vedas',
            user='postgres',
            password='sac123',
            host='localhost',
            port='5432'
        )
        return conn
    except psycopg2.Error as e:
        print("Error connecting to the database:", e)
        return None

def execute_query(conn, query,params=None):
    try:
        cur = conn.cursor()
        cur.execute(query)
        data = cur.fetchall()
        cur.close()
        return data
    except psycopg2.Error as e:
        print("Error executing query:", e)
        return []
    

def get_access_logs(tag=None,from_date=None,to_date=None): #get_data_from_access_logs
    conn=connect_to_database()

    if conn:
        cursor=conn.cursor()
        cursor.execute("select * from access_logs")
        log_data=cursor.fetchall()
        print(log_data)
        cursor.close()
        conn.close()

        return {

            "log_data":log_data
        }


def get_access_log_counts(tag=None, from_date=None, to_date=None):   #counts(4_params)
    tag_type = tag.get("tag_type") if tag else None
    
    conn = connect_to_database()
    
    if conn:
        # Counts of distinct IPs
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(DISTINCT IP) AS ip FROM access_logs")
        result = cursor.fetchone()
        distinct_ip = result[0]

        # Distinct URLs counts
        cursor.execute("SELECT COUNT(DISTINCT url) AS url FROM access_logs")
        result = cursor.fetchone()
        distinct_url = result[0]

        # Distinct referers
        cursor.execute("SELECT COUNT(DISTINCT referer) AS ref FROM access_logs")
        result = cursor.fetchone()
        distinct_ref = result[0]

        # Distinct values from tags table (APPS)
        cursor.execute("SELECT COUNT(DISTINCT value) AS ref FROM tags")
        result = cursor.fetchone()
        distinct_value_tags = result[0]

        cursor.close()
        conn.close()

        return [{
            "distinct_ip": distinct_ip,
            "distinct_url": distinct_url,
            "distinct_ref": distinct_ref,
            "distinct_value_tags": distinct_value_tags,
        }]



def get_access_log_daily_counts(tag=None,from_date=None,to_date=None):  #charts
    tag["tag_type"]
    return [{}]


def get_distinct_tags(tagtype):
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor() 
        cursor.execute("select distinct value from tags")
        apps=[row[0] for row in cursor.fetchall()]

        cursor.close()
        conn.close()

        return {

            "apps":apps
        }

def get_tag_pie_chart():
    conn = connect_to_database()
    if conn:
        query = "SELECT value, COUNT(*) AS cnt FROM tags GROUP BY value ORDER BY cnt DESC LIMIT 5;"
        data = execute_query(conn, query)
        conn.close()
        return data
    else:
        return []


@app.route('/')
def main():
    tag_count = get_tag_pie_chart()
    return render_template('dashboard.html',tag_count=tag_count)

if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True, port=5002)