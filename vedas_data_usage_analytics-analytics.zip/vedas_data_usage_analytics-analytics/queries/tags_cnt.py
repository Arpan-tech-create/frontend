import psycopg2

conn = psycopg2.connect(
        dbname='vedas',
        user='postgres',
        password='sac123',
        host='localhost',
        port='5432'
    )


cur=conn.cursor()

cur.execute("select value,count(*) as cnt from tags  group by value order by cnt desc limit 5 ")

data=cur.fetchall()
for row in data:
    print(row)


cur.close()
conn.close()