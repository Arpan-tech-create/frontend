import psycopg2

# Connect to the PostgreSQL database
conn = psycopg2.connect(
    dbname='vedas',
    user='postgres',
    password='sac123',
    host='localhost',
    port='5432'
)

# Create a cursor to interact with the database
cur = conn.cursor()

# Execute the SQL query to count records in the tags table grouped by date
cur.execute("""
    SELECT 
        DATE_TRUNC('day', timestamp) AS date,
        COUNT(*) AS count 
    FROM tags 
    GROUP BY date
    ORDER BY date;
""")

# Fetch all the data
data = cur.fetchall()

# Loop through the data and print each row
for row in data:
    date = row[0].strftime("%Y-%m-%d")
    count = row[1]
    print(f"{date} : count {count}")

# Close the cursor and the database connection
cur.close()
conn.close()
