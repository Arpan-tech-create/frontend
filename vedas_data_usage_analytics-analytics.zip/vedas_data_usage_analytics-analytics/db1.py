import psycopg2


def connect_to_database():
    try:
        conn = psycopg2.connect(
            dbname='postgres',
            user='postgres',
            password='sac123',
            host='localhost',
            port='54320'
        )
        return conn
    except psycopg2.Error as e:
        print("Error connecting to the database:", e)
        return None





def get_distinct_tag_type():
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()

        query = "select distinct tag_type from tag_types"
        cursor.execute(query)
        result = cursor.fetchall()

        cursor.close()
        conn.close()

        return result

def get_tag_values(tag_type):
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()

        query = "SELECT distinct value from tag_types WHERE tag_type = %s;"
        cursor.execute(query, (tag_type,))
        result = [row[0] for row in cursor.fetchall()]

        cursor.close()
        conn.close()

        return result

def get_data_query(tag_type, tag_value, group_by):
    conn = connect_to_database()
    if conn is not None:
        try:
            cursor = conn.cursor()
            query = """
                SELECT r.tag_type as referrer_type, 
                       r.value as referrer_value, 
                       b.value as base_url_value, 
                       count(r.req_id) as count
                FROM tags r
                JOIN tags b ON r.req_id = b.req_id
                WHERE r.tag_type = %s 
                  AND r.value = %s
                  AND b.tag_type = %s
                GROUP BY r.tag_type, r.value, b.value
                ORDER BY count DESC
                LIMIT 15
            """
            cursor.execute(query, (tag_type, tag_value, group_by))
            data = cursor.fetchall()
            cursor.close()
            return data
        except psycopg2.Error as e:
            print("Error executing SQL query:", e)
        finally:
            conn.close()
    return None

def get_data_for_app_by_service(selected_tag_value):
    try:
        conn = connect_to_database()
        cursor = conn.cursor()

     
        query = """
            select r.tag_type as referrer_type, r.value as referrer_value, b.value as base_url_value, count(r.req_id) as count
            from tags r
            join tags b on r.req_id = b.req_id
            where r.tag_type = 'base_url' and r.value = %s
              and b.tag_type = 'referrer'
            group by r.tag_type, r.value, b.value
            order by count desc limit 15
        """

        cursor.execute(query, (selected_tag_value,))
        result = cursor.fetchall()
      
       

        cursor.close()
        conn.close()

        return result

    except Exception as e:
        raise Exception(f"Error: {e}")


def get_data_for_source_by_service(selected_tag_value):
    try:
        conn = connect_to_database()
        cursor = conn.cursor()

     
        query = """
            select r.tag_type as referrer_type, r.value as referrer_value, b.value as base_url_value, count(r.req_id) as count
            from tags r
            join tags b on r.req_id = b.req_id
            where r.tag_type = 'base_url' and r.value = %s
              and b.tag_type = 'domain'
            group by r.tag_type, r.value, b.value
            order by count desc limit 15
        """

        cursor.execute(query, (selected_tag_value,))
        result = cursor.fetchall()
     
       

        cursor.close()
        conn.close()

        return result

    except Exception as e:
        raise Exception(f"Error: {e}")
    

def get_data_for_service_by_app(selected_tag_value):

    try:
        conn = connect_to_database()
        cursor = conn.cursor()

     
        query = """
            select r.tag_type as referrer_type, r.value as referrer_value, b.value as base_url_value, count(r.req_id) as count
            from tags r
            join tags b on r.req_id = b.req_id
            where r.tag_type = 'referrer' and r.value = %s
              and b.tag_type = 'base_url'
            group by r.tag_type, r.value, b.value
            order by count desc limit 15
        """

        cursor.execute(query, (selected_tag_value,))
        result = cursor.fetchall()
      
       

        cursor.close()
        conn.close()

        return result

    except Exception as e:
        raise Exception(f"Error: {e}")
    

def get_data_for_source_by_app(selected_tag_value):

    try:
        conn = connect_to_database()
        cursor = conn.cursor()

     
        query = """
            select r.tag_type as referrer_type, r.value as referrer_value, b.value as base_url_value, count(r.req_id) as count
            from tags r
            join tags b on r.req_id = b.req_id
            where r.tag_type = 'referrer' and r.value = %s
              and b.tag_type = 'domain'
            group by r.tag_type, r.value, b.value
            order by count desc limit 15
        """

        cursor.execute(query, (selected_tag_value,))
        result = cursor.fetchall()
        
       

        cursor.close()
        conn.close()

        return result

    except Exception as e:
        raise Exception(f"Error: {e}")

def get_data_for_app_by_source(selected_tag_value):

    try:
        conn=connect_to_database()
        cursor=conn.cursor()

        query = """
            select r.tag_type as referrer_type, r.value as referrer_value, b.value as base_url_value, count(r.req_id) as count
            from tags r
            join tags b on r.req_id = b.req_id
            where r.tag_type = 'domain' and r.value = %s
              and b.tag_type = 'referrer'
            group by r.tag_type, r.value, b.value
            order by count desc limit 15
        """
        cursor.execute(query,(selected_tag_value,))
        result=cursor.fetchall()

        cursor.close()
        conn.close()
        return result
    except Exception as e:
        raise Exception(f"Error: {e}")



def get_data_for_service_by_source(selected_tag_value):

    try:
        conn=connect_to_database()
        cursor=conn.cursor()

        query = """
            select r.tag_type as referrer_type, r.value as referrer_value, b.value as base_url_value, count(r.req_id) as count
            from tags r
            join tags b on r.req_id = b.req_id
            where r.tag_type = 'domain' and r.value = %s
              and b.tag_type = 'base_url'
            group by r.tag_type, r.value, b.value
            order by count desc limit 15
        """
        cursor.execute(query,(selected_tag_value,))
        result=cursor.fetchall()

        cursor.close()
        conn.close()
        return result
    except Exception as e:
        raise Exception(f"Error: {e}")


def get_latest_date():
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()
  
        query = "SELECT MAX(timestamp) FROM tags"
        cursor.execute(query)

        latest_date = cursor.fetchone()[0]
        print("latest date is:", latest_date)

        cursor.close()
        conn.close()

        return latest_date

    else:
     
        print("Failed to connect to the database")
        return None


def get_distinct_application_count(from_date=None, to_date=None):
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()

        query = "SELECT count(*) FROM (SELECT distinct value FROM tags WHERE timestamp >= %s AND timestamp <= %s AND tag_type='referrer') t"
        
        if from_date and to_date:
            cursor.execute(query, (from_date, to_date))
        else:
            cursor.execute(query)

        result = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return result
    
def get_distinct_domain_count(from_date=None, to_date=None):
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()

        query = "SELECT count(*) FROM (SELECT distinct value FROM tags WHERE timestamp >= %s AND timestamp <= %s AND tag_type='domain') t"
        
        if from_date and to_date:
            cursor.execute(query, (from_date, to_date))
        else:
            cursor.execute(query)

        result = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return result
    
def get_distinct_service_count(from_date=None, to_date=None):
    conn = connect_to_database()

    if conn:
        cursor = conn.cursor()

        query = "SELECT count(*) FROM (SELECT distinct value FROM tags WHERE timestamp >= %s AND timestamp <= %s and tag_type='base_url') t"
        
        if from_date and to_date:
            cursor.execute(query, (from_date, to_date))
        else:
            cursor.execute(query)

        result = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return result




def get_daily_tag_counts(from_date=None, to_date=None):  #bar_chart
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor() 

        if from_date and to_date:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags WHERE timestamp >= %s AND timestamp <= %s GROUP BY date ORDER BY date;"
            cursor.execute(query, (from_date, to_date))
        else:
            query = "SELECT DATE_TRUNC('day', timestamp) AS date, COUNT(*) AS count FROM tags GROUP BY date ORDER BY date;"
            cursor.execute(query)

        data = cursor.fetchall()
        cursor.close()
        conn.close()
        return data



def get_distinct_tags(tag_type,from_date=None,to_date=None):
 
   
    conn = connect_to_database()
    if conn:
        cursor = conn.cursor() 
        if from_date and to_date:
            query="select distinct value from tags where tag_type=%s and timestamp >= %s AND timestamp <= %s "
            cursor.execute(query,(tag_type,from_date,to_date))
        else:
              query="select distinct value from tags where tag_type=%s"
              cursor.execute(query,(tag_type,))

        apps = [row[0] for row in cursor.fetchall()]
      
        cursor.close()
        conn.close()
        return apps
    





    


def get_tag_counts_in_date_range(tag_type, from_date=None, to_date=None):
    conn = connect_to_database()
    if not conn:
        return []

    try:
        cursor = conn.cursor()

        query = """
            SELECT value, COUNT(*) AS cnt 
            FROM tags 
            WHERE tag_type = %s 
              AND value NOT IN ('vedas.sac.gov.in', 'vedas-sac-gov-in.translate.goog', 'vedas.sac.gov.in?page=6', 'www.vedas.sac.gov.in', 'localhost')
        """
        params = [tag_type]

        if from_date and to_date:
            query += " AND timestamp >= %s AND timestamp <= %s"
            params.extend([from_date, to_date])
        
        query += " GROUP BY value ORDER BY cnt DESC LIMIT 10;"

        cursor.execute(query, params)
        top_data = cursor.fetchall()

        print("TOP_IN_DB", top_data)

        cursor.close()
    except Exception as e:
        print(f"Error executing query: {e}")
        top_data = []
    finally:
        conn.close()

    return top_data




        




























































































































































































































































































































































































































































































































































