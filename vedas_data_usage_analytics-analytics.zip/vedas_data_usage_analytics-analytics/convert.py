import gzip
import shutil

def compress_log_file(input_filename, output_filename):
    with open(input_filename, 'rb') as f_in, gzip.open(output_filename, 'wb') as f_out:
        shutil.copyfileobj(f_in, f_out)


input_log_file = 'access.log.100'
output_log_file = 'access.log.100.gz'

compress_log_file(input_log_file, output_log_file)
